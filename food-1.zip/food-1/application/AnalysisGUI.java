package application;
/**
 * Filename:   TableGUI.java
 * Project:    Final Project
 * Authors:    D-team #61/ Lec 003
 *
 * Semester:   Fall 2018
 * Course:     CS400
 * 
 * Due Date:   DUE 12/Dec/2018 10pm
 * Version:    1.0
 * 
 * Credits:    N/A
 * 
 * Bugs:       N/A
 */

import java.util.List;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.chart.Chart;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

/*
 * AnalysisGUI creates the GUI presenting the nutrition analysis
 * with the given list of foodItems
 */
public class AnalysisGUI {

	public static void diplay(boolean empty, TableView<FoodItem> mealTable) {
		// Creates new stage
		Stage window = new Stage();
		window.setTitle("Meal Anaysis");
		window.setMinWidth(300);
		window.setMinHeight(300);
		window.initModality(Modality.APPLICATION_MODAL);
		GridPane layout = new GridPane();
		layout.setPadding(new Insets(5, 5, 5, 5));
		layout.setVgap(20);
		layout.setHgap(10);
		
		// if empty, show the user the message
		if (empty == true) {
			Label message = new Label("There is no food item in your meal list.\n Please Add items from the food list");
			message.setFont(Font.font("Verdana", 15));
			message.setStyle(
					"-fx-text-fill: #000 !important; -fx-highlight-text-fill: #000 !important; -fx-font-family: Arial");
			GridPane.setConstraints(message, 0, 0);
			layout.getChildren().add(message);
			layout.setAlignment(Pos.CENTER);
		} else {
			// creates pi chart for each nutrient
			List<TableColumn<FoodItem, ?>> mealList = mealTable.getColumns();
			TableColumn<FoodItem, ?> nameList = mealList.get(0);
			for (int i = 1; i < mealList.size() - 1; i++) {
				Chart chart = analysis(nameList, mealList.get(i));
				if (i > 3) {
					GridPane.setConstraints(chart, i - 3, 1);
				} else {
					GridPane.setConstraints(chart, i, 0);
				}
				layout.getChildren().add(chart);
			}
		}
		
		// Set up a close button 
		Button close = new Button("close");
		// Set up an action for the close button
		close.setOnAction(e -> window.close());
		GridPane.setConstraints(close, 3, 1);
		GridPane.setHalignment(close, HPos.RIGHT);
		GridPane.setValignment(close, VPos.BOTTOM);
		close.setMinSize(70, 10);
		layout.getChildren().add(close);

		Scene scene = new Scene(layout);
		window.setScene(scene);
		window.showAndWait();
	}

	// return the pi chart with given column of the table
	@SuppressWarnings("static-access")
	public static PieChart analysis(TableColumn<FoodItem, ?> nameList, TableColumn<FoodItem, ?> nutrient) {	
		ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
		int i = 0;
		Double value = null;
		while (nutrient.getCellData(i) != null) {
			String name = nameList.getCellData(i).toString();
			String v = nutrient.getCellData(i).toString();
			pieChartData.add(new PieChart.Data(name, value.valueOf(v)));
			i++;
		}

		PieChart pieChart = new PieChart(pieChartData);
		pieChart.setClockwise(true);
		pieChart.setTitle(nutrient.getText());
		pieChart.setMaxSize(350, 350);
		return pieChart;
	}

}