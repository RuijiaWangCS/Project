package application;

import java.util.HashMap;
import javafx.scene.control.CheckBox;
/**
 * This class represents a food item with all its properties.
 * 
 * @author aka
 */
public class FoodItem {
    // The name of the food item.
    private String name;

    // The id of the food item.
    private String id;

    // Map of nutrients and value.
    private HashMap<String, Double> nutrients;
    
    private CheckBox selected;
    
    /**
     * Constructor
     * @param name name of the food item
     * @param id unique id of the food item 
     */
    public FoodItem(String id, String name) {
        this.id = id;
        this.name = name;
        this.nutrients = new HashMap<String, Double>();
        this.selected = new CheckBox();
    }
    
    //constructor
     public FoodItem(String id, String name, HashMap<String, Double> nutrient) {
    	this.id = id;
    	this.name = name;
    	this.nutrients = nutrient;
    	this.selected = new CheckBox();
    }
     
     // constructor for deep copy
     public FoodItem(FoodItem that) {
    	 this.id = that.getID();
    	 this.name = that.getName();
    	 this.nutrients = that.getNutrients();
    	 this.selected = new CheckBox();
     }

    /**
     * Gets the name of the food item
     * 
     * @return name of the food item
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the unique id of the food item
     * 
     * @return id of the food item
     */
    public String getID() {
        // TODO : Complete
        return id;
    }
    
    /**
     * Gets the selected status of the food item
     * 
     * @return selected of the food item
     */
    public CheckBox getSelected() {
        return selected;
    }
    
    /**
     * Gets the nutrients of the food item
     * 
     * @return nutrients of the food item
     */
    public HashMap<String, Double> getNutrients() {
        // TODO : Complete
        return nutrients;
    }

    /**
     * Adds a nutrient and its value to this food. 
     * If nutrient already exists, updates its value.
     */
    public void addNutrient(String name, double value) {
        // TODO : Complete
        nutrients.put(name, value);
    }

    /**
     * Returns the value of the given nutrient for this food item. 
     * If not present, then returns 0.
     */
    public double getNutrientValue(String name) {
        // TODO : Complete
        if(nutrients.containsKey(name)) {
            return nutrients.get(name);
        }
        else {
            return 0;
        }
    }
    
    public void setSelected(CheckBox selected) {
        this.selected = selected;
    }
    
}