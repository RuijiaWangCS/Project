package application;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * This class is responsible for the back-end operations, including maintaining
 * the full list of fooditems, reading/saving fooditems from/to a files
 * 
 * @author sapan (sapan@cs.wisc.edu)
 */
public class FoodData implements FoodDataADT<FoodItem> {

	// List of all the food items.
	private List<FoodItem> foodItemList;

	// Map of nutrient and their corresponding index
	private HashMap<String, BPTree<Double, FoodItem>> indexes;

	// BTTrees for each nutrient
	private BPTree<Double, FoodItem> caloryTree;
	private BPTree<Double, FoodItem> carbTree;
	private BPTree<Double, FoodItem> fiberTree;
	private BPTree<Double, FoodItem> proteinTree;
	private BPTree<Double, FoodItem> fatTree;

	/**
	 * Public constructor
	 */
	public FoodData() {
		foodItemList = new ArrayList<FoodItem>();
		indexes = new HashMap<String, BPTree<Double, FoodItem>>();
	}

	/*
	 * 
	 * @see skeleton.FoodDataADT#loadFoodItems(java.lang.String)
	 */
	@Override
	public void loadFoodItems(String filePath) {
		if(!this.foodItemList.isEmpty()) {
			foodItemList.clear();
		}
		try {
			// reading File 
			BufferedReader br = new BufferedReader(new FileReader(filePath));
			String line;
			while ((line = br.readLine()) != null) {
				String[] values = line.split(",");
				// only valid if there are 12 elements in each line
				if (values.length == 12) {
					// creates new Food item 
					FoodItem food = new FoodItem(values[0], values[1]);
					food.addNutrient(values[2], Double.parseDouble(values[3]));
					food.addNutrient(values[4], Double.parseDouble(values[5]));
					food.addNutrient(values[6], Double.parseDouble(values[7]));
					food.addNutrient(values[8], Double.parseDouble(values[9]));
					food.addNutrient(values[10], Double.parseDouble(values[11]));
					// add foodItem to foodItemList
					foodItemList.add(food);
				}
			}
			br.close();
			Collections.sort(foodItemList, new FoodItemComparator<FoodItem>() {
				@Override
				public int compare(FoodItem f1, FoodItem f2) {
					return f1.getName().compareTo(f2.getName());
				}
			});

			// Creates BTrees for each nutrient
			String calory = "calories";
			String carb = "carbohydrate";
			String fiber = "fiber";
			String protein = "protein";
			String fat = "fat";
			int BF = 3;
			caloryTree = new BPTree<>(BF);
			carbTree = new BPTree<>(BF);
			fiberTree = new BPTree<>(BF);
			proteinTree = new BPTree<>(BF);
			fatTree = new BPTree<>(BF);
			
			// inserting nutritional info into each BPTrees
			for (int i = 0; i < foodItemList.size(); i++) {
				FoodItem food = foodItemList.get(i);
				caloryTree.insert(food.getNutrientValue(calory), food);
				caloryTree.insert(food.getNutrientValue(calory), food);
				carbTree.insert(food.getNutrientValue(carb), food);
				fiberTree.insert(food.getNutrientValue(fiber), food);
				proteinTree.insert(food.getNutrientValue(protein), food);
				fatTree.insert(food.getNutrientValue(fat), food);
			}

			// inserting each BPTrees in to the index
			indexes.put(calory, caloryTree);
			indexes.put(carb, carbTree);
			indexes.put(fiber, fiberTree);
			indexes.put(protein, proteinTree);
			indexes.put(fat, fatTree);

		} catch (FileNotFoundException e) {
			e.getMessage();
		} catch (IOException e) {
			e.getMessage();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see skeleton.FoodDataADT#filterByName(java.lang.String)
	 */
	@Override
	public List<FoodItem> filterByName(String substring) {
		// List to maintain filtered items
		List<FoodItem> filterByName = new ArrayList<FoodItem>();
		
		// go through each item in the FOoItemList and store the food Item with the
		// substring into the List
		for (int i = 0; i < foodItemList.size(); i++) {
			if (foodItemList.get(i).getName().contains(substring)) {
				filterByName.add(foodItemList.get(i));
			}
		}
		return filterByName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see skeleton.FoodDataADT#filterByNutrients(java.util.List)
	 */
	@Override
	public List<FoodItem> filterByNutrients(List<String> rules) {
		// Set to maintain the filtered items
		//(keeps the intersection of results if there are multiple rules)
		Set<FoodItem> set = new HashSet<FoodItem>(foodItemList);
		
		for (int i = 0; i < rules.size(); i++) {
			String[] rule = rules.get(i).split("\\s");
			String nutrient = rule[0];
			String comparator = rule[1];
			double value = Double.parseDouble(rule[2]);
			// Gets the filtering result from one rule
			List<FoodItem> filtered = indexes.get(nutrient).rangeSearch(value, comparator);
			Set<FoodItem> Subset = new HashSet<FoodItem>(filtered);
			// keeps the intersection of previous results
			set.retainAll(Subset);
		}
		List<FoodItem> list = new ArrayList<FoodItem>(set);
		return list;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see skeleton.FoodDataADT#addFoodItem(skeleton.FoodItem)
	 */
	@Override
	public void addFoodItem(FoodItem foodItem) {
		foodItemList.add(foodItem);
		Collections.sort(foodItemList, new FoodItemComparator<FoodItem>() {
			@Override
			public int compare(FoodItem f1, FoodItem f2) {
				return f1.getName().compareTo(f2.getName());
			}
		});
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see skeleton.FoodDataADT#getAllFoodItems()
	 */
	@Override
	public List<FoodItem> getAllFoodItems() {

		return foodItemList;
	}

	@Override
	public void saveFoodItems(String file) {
		BufferedWriter writer = null;
		try {
			writer = new BufferedWriter(new FileWriter(file));
			// list of all the fooditems before filtering and after adding new fooditems
			List<FoodItem> list = this.getAllFoodItems();
			
			// iterate through each fooditem to save them in the format
			Iterator<FoodItem> it = list.iterator();
			while (it.hasNext()) {
				FoodItem item = it.next();
				String id = item.getID();
				String name = item.getName();
				HashMap<String, Double> nutrients = item.getNutrients();

				String str = id + "," + name + ",calories," + nutrients.get("calories") + ",fat," + nutrients.get("fat")
						+ ",carbohydrate," + nutrients.get("carbohydrate") + ",fiber," + nutrients.get("fiber")
						+ ",protein," + nutrients.get("protein");
				writer.write(str);
				writer.newLine();

			}
			writer.close();
		} catch (IOException e) {
			e.getMessage();
		} finally {
			if (writer != null)
				try {
					writer.close();
				} catch (IOException f) {

				}
		}
	}

	

}