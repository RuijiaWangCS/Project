package application;

/**
 * Filename:   TableGUI.java
 * Project:    Final Project
 * Authors:    D-team #61/ Lec 003
 *
 * Semester:   Fall 2018
 * Course:     CS400
 * 
 * Due Date:   DUE 12/Dec/2018 10pm
 * Version:    1.0
 * 
 * Credits:    N/A
 * 
 * Bugs:       N/A
 */

import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

/*
 * This HelpGUI is responsible for creating HelpGUI
 * 
 */
public class HelpGUI {

	// pops a new window with instruction on how to use this application
	public static void Display() {
		
		// Sets up new stage
		Stage window = new Stage();
		window.setTitle("Help");
		window.setMinWidth(300);
		window.setMinHeight(300);
		window.initModality(Modality.APPLICATION_MODAL);
		
		// Sets up new stage for displaying the instruction
		GridPane layout= new GridPane();
		layout.setPadding(new Insets(5,5,5,5));
		layout.setVgap(20);
		layout.setHgap(10);
		
		// Actual content of the instruction
		Label message = new Label("STEPS\n\n 1. Pick food items from the food list on the left\n 2. Add them to the Meal List by pressing \">>\" button\n 3. Click on the \"Get Nutrition Summary\" button to view the nutrient summary");
		message.setFont(Font.font("Verdana", 15));
		message.setStyle("-fx-text-fill: #000 !important; -fx-highlight-text-fill: #000 !important; -fx-font-family: Arial");
		GridPane.setConstraints(message, 0, 0);
		layout.getChildren().add(message);
		layout.setAlignment(Pos.CENTER);
		
		// Sets up close button and its action
		Button close = new Button("close");	
		close.setOnAction(e -> window.close());
		GridPane.setConstraints(close, 0, 1);
		layout.getChildren().add(close);
		
		GridPane.setHalignment(close, HPos.RIGHT);
		Scene scene = new Scene(layout);
		window.setScene(scene);
		window.showAndWait();

	}
}
