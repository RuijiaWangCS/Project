package application;
/**
 * Filename:   AddFoodGUI.java
 * Project:    Final Project
 * Authors:    D-team #61/ Lec 003
 *
 * Semester:   Fall 2018
 * Course:     CS400
 * 
 * Due Date:   DUE 12/Dec/2018 10pm
 * Version:    1.0
 * 
 * Credits:    N/A
 * 
 * Bugs:       N/A
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;

/*
 * Filter class is responsible for creating GUI for filtering container
 */
public class Filter {

	/*
	 * Fields
	 */
	private ComboBox<String> SearchByNutrient;
	private ComboBox<String> FilteringRules;
	private TextField NutrientValue;
	private Label CountView;
	private ObservableList<FoodItem> FoodItemList;
	private FoodData fd;
	private Button nameSearchButton;

	// list of nutrients to be filtered
	private static final ObservableList<String> NutrientOptions = FXCollections.observableArrayList("calories", "fat",
			"carbohydrate", "fiber", "protein");

	// list of rules to be applied
	private static final ObservableList<String> RuleOptions = FXCollections.observableArrayList("==", ">=", "<=");

	/*
	 * Constructors
	 */
	public Filter(ObservableList<FoodItem> FoodItemList, FoodData fd, Label CountView) {
		// Filter by Name
		SearchByNutrient = new ComboBox<String>(NutrientOptions);
		SearchByNutrient.getSelectionModel().selectFirst();
		// Filter by Rules
		FilteringRules = new ComboBox<String>(RuleOptions);
		FilteringRules.getSelectionModel().selectFirst();

		// Textfields for nutrient value input
		NutrientValue = new TextField();
		NutrientValue.setPromptText("100");
		NutrientValue.setPrefWidth(50);
		limitTextInput(NutrientValue);
		this.CountView = CountView;
		this.fd = fd;
		this.FoodItemList = FoodItemList;
	}

	// getter and setter methods
	public ComboBox<String> getSearchByNutrient() {
		return SearchByNutrient;
	}

	public void setSearchByNutrient(ComboBox<String> searchByNutrient) {
		SearchByNutrient = searchByNutrient;
	}

	public ComboBox<String> getFilteringRules() {
		return FilteringRules;
	}

	public void setRuleOptions(ComboBox<String> ruleOptions, ComboBox<String> FilteringRules) {
		this.FilteringRules = FilteringRules;
	}

	public TextField getNutrientValue() {
		return NutrientValue;
	}

	public void setNutrientValue(TextField nutrientValue) {
		NutrientValue = nutrientValue;
	}

	/**
	 * Creates the container containing the texfields and combobox for applying
	 * filter rules
	 * 
	 * @return HBox nutrientSearchBox
	 */
	public HBox makeFilterOptions() {
		// Sets up the container GUI
		HBox nutrientSearchBox = new HBox();
		nutrientSearchBox.setPadding(new Insets(3, 3, 3, 3));
		nutrientSearchBox.setSpacing(10);

		nutrientSearchBox.getChildren().addAll(SearchByNutrient, FilteringRules, NutrientValue);
		return nutrientSearchBox;
	}

	/**
	 * Creates the overall GUI containing both name/nutrient filtering Deals with
	 * adding more rules and removing rules from the display
	 * 
	 * @return
	 */
	public GridPane makeFilterGrid() {

		GridPane filterGP = new GridPane();
		filterGP.setPadding(new Insets(10, 10, 10, 10));
		filterGP.setVgap(8);
		filterGP.setHgap(10);

		// Title for name search
		Label nameSearchLabel = new Label("Food Name");

		// TextField for name search
		TextField nameSearchInput = new TextField();
		nameSearchInput.setPromptText("Pizza");
		nameSearchInput.setPrefWidth(100);
		GridPane.setConstraints(nameSearchLabel, 0, 0);
		GridPane.setConstraints(nameSearchInput, 0, 1);

		// Button for name Search
		nameSearchButton = new Button("Search");
		GridPane.setConstraints(nameSearchButton, 1, 1);

		// Sets up nameSearchButton action
		nameSearchButton.setOnAction(e -> {
			List<FoodItem> filtered = fd.filterByName(nameSearchInput.getText());
			FoodItemList.setAll(filtered);
			Collections.sort(FoodItemList, new FoodItemComparator<FoodItem>() {
				@Override
				public int compare(FoodItem f1, FoodItem f2) {
					return f1.getName().compareTo(f2.getName());
				}
			});
			Integer count = FoodItemList.size();
			CountView.setText(count.toString());
		});

		// container for storing the name search elements
		GridPane nameSearchbox = new GridPane();
		nameSearchbox.setPadding(new Insets(3, 3, 3, 3));
		nameSearchbox.setHgap(1);
		nameSearchbox.setVgap(1);
		nameSearchbox.getChildren().addAll(nameSearchLabel, nameSearchInput, nameSearchButton);
		nameSearchbox.setAlignment(Pos.CENTER_LEFT);
		GridPane.setConstraints(nameSearchbox, 0, 0);

		// Creates GUI for filtering (by nutrient)
		// List for storing the multiple filter ruls
		List<Filter> filters = new ArrayList<Filter>();

		// Box to maintain the filter box which changes in size dynamically
		VBox filterExtention = new VBox();
		GridPane.setConstraints(filterExtention, 0, 2);

		// Displays the default GUI(only one filtering rule)
		Filter first = new Filter(FoodItemList, fd, CountView);
		HBox nutrientSearchBoxFirst = first.makeFilterOptions();
		filters.add(first);

		
		// Button to apply filtering rules on the table
		Button filterButton = new Button("filter");
		nutrientSearchBoxFirst.getChildren().add(filterButton);
		GridPane.setConstraints(nutrientSearchBoxFirst, 0, 1);
		// Sets up action for fiterButton(apply filter rules)
		filterButton.setOnAction(e -> {
			List<String> rules = new ArrayList<String>();
			for (Filter f : filters) {
				String rule = f.getSearchByNutrient().getValue() + " ";
				rule += f.getFilteringRules().getValue() + " ";
				rule += f.getNutrientValue().getText();
				// rule is only effective if all the three fields are filled(other two are auto
				// filled)
				if (!f.getNutrientValue().getText().isEmpty()) {
					rules.add(rule);
				}
			}

			if (rules.isEmpty()) {
				// if there's no input, clear the filter
				FoodItemList.setAll(fd.getAllFoodItems());
			} else {
				// if there is input in the filter, place the rule
				FoodItemList.setAll(fd.filterByNutrients(rules));

			}
			Integer count = FoodItemList.size();

			Collections.sort(FoodItemList, new FoodItemComparator<FoodItem>() {
				@Override
				public int compare(FoodItem f1, FoodItem f2) {
					return f1.getName().compareTo(f2.getName());
				}
			});
			CountView.setText(count.toString());

		});
				

		// Button to add filtering
		Button addMore = new Button("+");
		addMore.setShape(new Circle(5));
		GridPane.setConstraints(addMore, 1, 1);
		// sets up action for addMore(Add one filter rule to the display)
		addMore.setOnAction(e -> {
			Filter filter = new Filter(FoodItemList, fd, CountView);
			filters.add(filter);
			HBox nutrientSbox = filter.makeFilterOptions();
			filterExtention.getChildren().add(nutrientSbox);
		});
		

		// Button to remove one filtering rule
		Button removeFilter = new Button("-");
		removeFilter.setShape(new Circle(5));
		GridPane.setConstraints(removeFilter, 2, 1);
		// Sets up action for removing filtering rule from the view
		removeFilter.setOnAction(e -> {
			// if there is more than 1 filters remove functionality fires
			if (filters.size() >= 2) {
				filterExtention.getChildren().remove(filters.size() - 2);
				filters.remove(filters.size() - 1);
			}

		});

		
		// Button to clear all the filtering rules
		Button clear = new Button("clear");
		clear.setShape(new Circle(5));
		GridPane.setConstraints(clear, 3, 1);
		// sets up action for clear filter(clearing the filtered result from the
		// display)
		clear.setOnAction(e -> {
			FoodItemList.setAll(fd.getAllFoodItems());
			Integer count = FoodItemList.size();
			CountView.setText(count.toString());
		});
		GridPane.setConstraints(filterButton, 3, 1);

		
		// Setting the GridPane for the filter menu.
		filterGP.getChildren().addAll(nutrientSearchBoxFirst, nameSearchbox, addMore, clear, filterExtention,
				removeFilter);
		return filterGP;
	}
	
	

	private void limitTextInput(TextField text) {
		text.textProperty().addListener(new ChangeListener<String>() {
			public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
				if (!text.getText().matches("\\d*")) {
					text.setText(newValue.replaceAll("[^\\d]", ""));
				}
			}
		});
	}

}
