package application;

import java.util.Comparator;

public interface FoodItemComparator<FoodItem> extends Comparator<FoodItem> {
	

	int compare(application.FoodItem f1, application.FoodItem f2);
}
