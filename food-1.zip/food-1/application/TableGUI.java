package application;

/**
 * Filename:   TableGUI.java
 * Project:    Final Project
 * Authors:    D-team #61/ Lec 003
 *
 * Semester:   Fall 2018
 * Course:     CS400
 * 
 * Due Date:   DUE 12/Dec/2018 10pm
 * Version:    1.0
 * 
 * Credits:    N/A
 * 
 * Bugs:       N/A
 */

import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

/*
 * Tabel GUI is responsible for creating a table GUI with
 * given specific list of FoodItems
 */
public class TableGUI {
	
	/*
	 * Fields
	 */
	private ObservableList<FoodItem> table;
	private TableView<FoodItem> tableView;
    private FoodData fd;
    
    /*
     * Constructors
     */
    public TableGUI(FoodData fd, ObservableList<FoodItem> table) {   	
    	this.fd = fd;
    	this.table =  FXCollections.observableArrayList();;
    }
    

    //Get the list of fooditems loaded from the specified path
    public ObservableList<FoodItem> getItems(String path){
        fd.loadFoodItems(path);
        ObservableList<FoodItem> foodList = FXCollections.observableArrayList(fd.getAllFoodItems());
        table.addAll(foodList);
        return table;
    }
    
    // Sets the column of a table
    private  TableColumn<FoodItem, String> createColumn(String columnName) {
    	// column object
        TableColumn<FoodItem, String> nameColumn = new TableColumn<FoodItem, String>(columnName);
        // if the column is the for the name field just fill in the content by accessing foodItem's name field
        if(columnName.equals("name")) {
            nameColumn.setCellValueFactory(new PropertyValueFactory<>(columnName));
        }else {
        	// column is for the nutrition, 
        	//nutrition field is in Map, retrieve the nutrition value 
        	//by the nutrition name and fill in the content with the vlalue 
            nameColumn.setCellValueFactory(new Callback <CellDataFeatures<FoodItem, String>, ObservableValue<String>>(){
                    @SuppressWarnings({ "unchecked", "rawtypes" })
					public ObservableValue<String> call(CellDataFeatures<FoodItem, String> p){
                        return new ReadOnlyObjectWrapper(p.getValue().getNutrientValue(columnName));
                    }
            });
        }
        return nameColumn;
    }

    
 // Creates table for storing food items
    @SuppressWarnings("unchecked")
    public TableView<FoodItem> createTable(ObservableList<FoodItem> list){
        //Name column
        TableColumn<FoodItem, String> nameColumn = createColumn("name");
        nameColumn.setMinWidth(130);
        
        //Calories column
        TableColumn<FoodItem, String> caloryColumn = createColumn("calories");
        
        //Fat column
        TableColumn<FoodItem, String> fatColumn = createColumn("fat");
        
        //Carbohydrate column
        TableColumn<FoodItem, String> carbohydrateColumn = createColumn("carbohydrate");

        //Fiber column
        TableColumn<FoodItem, String> fiberColumn = createColumn("fiber");
        
        //Fiber column
        TableColumn<FoodItem, String> proteinColumn = createColumn("protein");
        
        // Selection column for selecting items to add to the meal list
        TableColumn<FoodItem, CheckBox> ButtonColumn = new TableColumn<FoodItem, CheckBox>("select");
        ButtonColumn.setCellValueFactory(new PropertyValueFactory<>("selected"));
        ButtonColumn.setEditable(true);
 
        // Sets up the overall GUI for the table
        tableView = new TableView<FoodItem>();
        tableView.setItems(list);
        tableView.getColumns().addAll(nameColumn, caloryColumn, fatColumn, carbohydrateColumn, fiberColumn, proteinColumn,  ButtonColumn);
        tableView.setEditable(true);
        tableView.setMaxWidth(500);
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        return tableView;
        
    }
}
