package application;
/**
 * Filename:   AddFoodGUI.java
 * Project:    Final Project
 * Authors:    D-team #61/ Lec 003
 *
 * Semester:   Fall 2018
 * Course:     CS400
 * 
 * Due Date:   DUE 12/Dec/2018 10pm
 * Version:    1.0
 * 
 * Credits:    N/A
 * 
 * Bugs:       N/A
 */

import java.util.Collections;
import java.util.HashMap;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;

/*
 * AddFoodGUI is responsible for creating input fields GUI for adding new FoodItem to the
 * FoodItemList. FoodItemList, FoodData, and lebel for count(of items in foodlist) is passed 
 * from the Gui object, create/update tables.
 */

public class AddFoodGUI {
	
	/*
	 * Fields
	 */
	private ObservableList<FoodItem> FoodItemList;
	private FoodData fd;
	private Label CountView;
	
	/*
	 * Constructor
	 */
	public AddFoodGUI(ObservableList<FoodItem> FoodItemList, FoodData fd, Label CountView) {
		this.FoodItemList = FoodItemList;
		this.fd = fd;
		this.CountView = CountView;
		
	}
	/**
	 * 
	 * @return GridPane newFoodItem
	 */
	public GridPane createAddFood() {
		 // Creates grid for entering new food item
        GridPane newFoodItem = new GridPane();
        newFoodItem.setPadding(new Insets(10,10,10,10));
        newFoodItem.setVgap(8);
        newFoodItem.setHgap(5);
        
        
        // Creates label for instruction(entering new food item)
        Label newFoodItemLabel = new Label("ADD FOOD ITEM");
        newFoodItemLabel.setFont(Font.font("Verdana", 15));
        newFoodItemLabel.setStyle("-fx-underline: true");
        newFoodItemLabel.setMinWidth(200);
        GridPane.setConstraints(newFoodItemLabel, 0, 0);  

        // Creates field for typing foodName
        // Label for foodName input
        Label newfoodItemL = new Label("Food Name");
        GridPane.setConstraints(newfoodItemL,0, 1);
        // Creates textfield for typing the name of the new food item
        TextField newFoodName = new TextField();
        newFoodName.setPromptText("pancake");
        GridPane.setConstraints(newFoodName,0,2);
        
        // Creates field for typing foodName
        // Label for new food item calorie
        
        
        Label newFoodItemCalory = new Label("Calories");
        GridPane.setConstraints(newFoodItemCalory, 1, 1);
        // Creates textfield for typing the value of calories  
        TextField newFoodCalory = setUpTextField("calories");  
        GridPane.setConstraints(newFoodCalory,1,2);

        // Creates label for new food item Fat
        Label newFoodItemFat = new Label("Fat");
        GridPane.setConstraints(newFoodItemFat,2,1 );
        // Creates textfield for typing the value of Fat        
        TextField newFoodFat = setUpTextField("fat");
        GridPane.setConstraints(newFoodFat,2,2);
        
        
        // Creates label for new food item fiber
        Label newFoodItemFiber = new Label("Fiber");
        GridPane.setConstraints(newFoodItemFiber,4,1 );
        // Creates textfield for typing the value of FIber              
        TextField newFoodFiber = setUpTextField("fiber");
        GridPane.setConstraints(newFoodFiber,4,2);
    
 
        
        // Creates label for new food item carb
        Label newFoodItemCarb = new Label("Carb");
        GridPane.setConstraints(newFoodItemCarb,3,1 );
        // Creates textfield for typing the value of Carb               
        TextField newFoodCarb = setUpTextField("Carb");
        GridPane.setConstraints(newFoodCarb,3,2);
        
       
        
        // Creates label for new food item protein
        Label newFoodItemProtein = new Label("Protein");
        GridPane.setConstraints(newFoodItemProtein,5,1 );
        // Creates textfield for typing the value of Carb               
        TextField newFoodProtein = setUpTextField("protein");
        GridPane.setConstraints(newFoodProtein,5,2);
        
        // Creates label for new food item ID
        Label newFoodItemID = new Label("ID");
        GridPane.setConstraints(newFoodItemID, 6,1);
        // Creates textfield for typing the value of ID               
        TextField newFoodID = setUpTextField("ID");
        GridPane.setConstraints(newFoodID,6,2);      
        
        
        // add button for the food table
        Button addNewFoodButton = new Button("Add");
        // Sets up action for addNewFoodButton
        addNewFoodButton.setOnAction(e-> {
        	try {
        		// Create map of nutrient name and its values
        		HashMap<String, Double> nutrient = new HashMap<String, Double>();
                nutrient.put("calories", Double.parseDouble(newFoodCalory.getText()));
                nutrient.put("fiber", Double.parseDouble(newFoodFiber.getText()));
                nutrient.put("protein", Double.parseDouble(newFoodProtein.getText()));
                nutrient.put("carbohydrate", Double.parseDouble(newFoodCarb.getText()));
                nutrient.put("fat", Double.parseDouble(newFoodFat.getText()));
                
                // construct new foodItem with the new name, nutrient map and ID
                FoodItem food = new FoodItem(newFoodID.getText(), newFoodName.getText(),nutrient); 
                // place the new foodItem object into the FoodItemList

                FoodItemList.add(food);
                
                // Sort the food Items
                Collections.sort(FoodItemList, new FoodItemComparator<FoodItem>() {
    				@Override
    				public int compare(FoodItem f1, FoodItem f2) {
    					return f1.getName().compareTo(f2.getName());
    				}
    			});
                
                
               
                // place the new foodItem to the FoodData object 
                fd.addFoodItem(food);
                
                // update the foodItem counter and its display
                Integer count = FoodItemList.size();
                CountView.setText(count.toString());
                
        	} catch (Exception e1) {
        		Label alarm = new Label("Please complete all the fields");
        		alarm.setStyle("-fx-text-fill: red;");
        		GridPane.setConstraints(alarm,0,3);
        		newFoodItem.getChildren().add(alarm);
        	}
            
            
        });
        
        // Sets up the GUI of the add food field container
        GridPane.setConstraints(addNewFoodButton,6,3);
        GridPane.setHalignment(addNewFoodButton, HPos.RIGHT);
        newFoodItem.getChildren().addAll(newFoodItemID, newFoodID, newFoodItemCarb,newFoodCarb,newFoodItemFiber,newFoodFiber,newFoodItemProtein,newFoodProtein, newfoodItemL, newFoodItemCalory, newFoodItemFat, newFoodName, newFoodCalory, newFoodFat, addNewFoodButton, newFoodItemLabel);
        newFoodItem.setMaxWidth(500);
        GridPane.setConstraints(newFoodItem,0,4);   
        return newFoodItem;
	}
	
	// Limit the TextField input value to be numbers. 
	// If non-numerical values are typed, they are automatically erased 
	private void limitTextInput(TextField text) {
		text.textProperty().addListener(new ChangeListener<String>() {
            public void changed(ObservableValue<? extends String> observable, String oldValue, String newValue) {
                if(!text.getText().matches("\\d*")) {
                    text.setText(newValue.replaceAll("[^\\d]", ""));
                }
            }
        });
	}
	
	// Set up the Text Field property for each Nutrient passed in
	private TextField setUpTextField(String nutritient) {
        // Creates textfield for typing the value of calories
        TextField nutrient = new TextField();
        nutrient.setPromptText("100");
        nutrient.setMinWidth(50);
        // Restricts negative or no-numeric values   
        limitTextInput(nutrient);
        
        return nutrient;
	}
	
}
