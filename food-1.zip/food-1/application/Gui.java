package application;
/**
 * Filename:   Gui.java
 * Project:    Final Project
 * Authors:    D-team #61/ Lec 003
 *
 * Semester:   Fall 2018
 * Course:     CS400
 * 
 * Due Date:   DUE 12/Dec/2018 10pm
 * Version:    1.0
 * 
 * Credits:    N/A
 * 
 * Bugs:       N/A
 */


import java.io.File;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableView;

import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/*
 * Class maintains the primary GUI of the FoodQuerry project.
 * This depends on the other supplementary GUI classes(HelpGUI, FilterGUI, TableGUI, Analysis GUI and AddFoodGUI)
 * 
 */
public class Gui {
	
	/**
	 *  Fields
	 */
	
	// Maintains the foodItems in the Food table and Meal Table
    private TableView<FoodItem> Foodtable;
    private TableView<FoodItem> MealTable;
    private ObservableList<FoodItem> FoodItemList;
    private ObservableList<FoodItem> MealItemList;
    private AddFoodGUI newFoodGUI;
    // FoodData object for data operations and maintaining the whole food items 
    // keeps the whole food list before filtering and after adding new items
    private FoodData fd;
       
    // To keep track of the number of food items in the FoodItemList to be displayed 
    private Label CountView;
    private Integer count;
    
    // Gui Object responsible for making tables GUI
    private TableGUI foodListGUI;
    
    /*
     * Constructor
     */
    public Gui() {
        fd = new FoodData();
        FoodItemList = FXCollections.observableArrayList();
        MealItemList = FXCollections.observableArrayList();
        Foodtable = new TableView<FoodItem>();
        MealTable = new TableView<FoodItem>();
        
     // Keeps track of the number of food items in display
        count = FoodItemList.size();
        CountView = new Label(count.toString()); 
        
        // GUI for FoodItemList
        foodListGUI = new TableGUI(fd, FoodItemList);  

        
        // get the items from the default file for the default display
        FoodItemList = foodListGUI.getItems("foodItems.csv");

        // GUI for new Food add form
        newFoodGUI = new AddFoodGUI(FoodItemList, fd, CountView);

        
    }
    
                
        /**
         * Sets up the Default GUI of the primary page of the project.
         * returns the Scene object.
         * @param primaryStage
         * @return scene
         */
        public Scene createContent(Stage primaryStage) {
            
            try {
            	// Root container
                BorderPane root = new BorderPane();

                // Sets the title for the window
                primaryStage.setTitle("FoodQuerry");
                
                // Sets the title for the Application
                VBox Top = new VBox();

                // Creates Filtering Menu 
                Filter filter = new Filter(FoodItemList, fd, CountView);

                
                GridPane filterGP = filter.makeFilterGrid();
                GridPane.setHalignment(filterGP, HPos.CENTER);
                filterGP.getStyleClass().add("filterGP");
                
                // Creates FoodTable
                Foodtable = foodListGUI.createTable(FoodItemList);

                // Creates new grid for FoodTable, stores the table title, the table itself, and an add button
                GridPane FoodTableGrid = new GridPane();
                FoodTableGrid.setPadding(new Insets(10,10,10,10));
                FoodTableGrid.setVgap(8);
                FoodTableGrid.setHgap(30);
                GridPane.setConstraints(Foodtable,0,3);
                            
                
                // Creates a container for maintaining the counter of foodItems
                // CountView contains the value of the number of items 
                HBox counter = new HBox();
                Label counterLabel = new Label("Number of Food items   ");             
                counter.getChildren().addAll(counterLabel, CountView);
                GridPane.setConstraints(counter, 0 ,2);

                // Creates input fields for adding new FoodItem
                GridPane newFoodItem = newFoodGUI.createAddFood();
       
                // add title for the food table
                Label FoodTableLabel = new Label("Food List");
                FoodTableLabel.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
                GridPane.setConstraints(FoodTableLabel,0,0);
                GridPane.setHalignment(FoodTableLabel, HPos.CENTER);

                // adds filter menu to the tableGrid
                GridPane.setConstraints(filterGP,0,1);
                
                FoodTableGrid.getChildren().addAll(filterGP, Foodtable, newFoodItem, FoodTableLabel, counter);
                
                // Creates Menu Table
                TableGUI mealTableGUI = new TableGUI(fd, MealItemList);
                MealTable = mealTableGUI.createTable(MealItemList);
                
                // By default, there is no item in the meal list.
                MealTable.setPlaceholder(new Label("There is no food item in the meal list\nPlease Select food items from the left"));
                GridPane.setConstraints(MealTable,0,3);
                

                // Creates grid storing meal table, table tile and remove button
                GridPane MenutableGrid = new GridPane();
                MenutableGrid.setPadding(new Insets(10,10,10,10));
                MenutableGrid.setVgap(8);
                MenutableGrid.setHgap(30);
                
                // Creates title for the Table
                Label MenuTableLabel = new Label("Selected Meal");
                MenuTableLabel.setFont(Font.font("Verdana", FontWeight.BOLD, 20));
                GridPane.setConstraints(MenuTableLabel,0,0);
                GridPane.setHalignment(MenuTableLabel, HPos.CENTER);
                
                
                // Create remove functionality of meal table
                // text for remove Button
                Label removeButtonText = new Label("REMOVE ITEMS FROM MEAL LIST");
                removeButtonText.setFont(Font.font("Verdana", 15));
                removeButtonText.setStyle("-fx-underline: true");

                // button for remove items from the meal
                Button removeButton = new Button("Remove");
                
                // Sets up removeButton action
                // Removes the selected items from the MealList
                removeButton.setOnAction(e->{
                    Set<FoodItem> set = new HashSet<FoodItem>();
                    for (FoodItem food: MealItemList) {
                        if(food.getSelected().isSelected()) {
                            set.add(food);
                            food.getSelected().setSelected(false);
                        }
                    }
                    MealItemList.removeAll(set);
                });
                
                // Set up remove button alignment
                HBox removeFromMeal = new HBox();
                removeFromMeal.setSpacing(10);
                removeFromMeal.getChildren().addAll(removeButtonText, removeButton);
                GridPane.setConstraints(removeFromMeal,0,4);
                removeFromMeal.setAlignment(Pos.BOTTOM_RIGHT);
                
                
                // Creates functionality of Nutrition analysis
                Button analyseButton = new Button("Get Nutrition Summary");
                analyseButton.setOnAction(e -> AnalysisGUI.diplay(MealTable.getItems().isEmpty(), MealTable));
                GridPane.setConstraints(analyseButton, 0, 2);
                GridPane.setHalignment(analyseButton, HPos.CENTER);
                MenutableGrid.getChildren().addAll(removeFromMeal, MealTable, MenuTableLabel, analyseButton);
                
                
                //Creates outer grid to store the food table grid and meal table grid
                GridPane tableGrid = new GridPane();
                tableGrid.setPadding(new Insets(10,10,10,10));
                tableGrid.setVgap(8);
                tableGrid.setHgap(30);
                
                // Creates "add Food to Meal" functionality
                // Creates a button/ label for adding a food item to the meal list
                Label addMealabel = new Label("Add to Meal");
                Button addMealButton = new Button(">>");  
                // Sets up action for addMealButton
                addMealButton.setOnAction(e->{
                    Set<FoodItem> set = new HashSet<FoodItem>();
                    set.addAll(MealItemList);
                    for (FoodItem food: FoodItemList) {
                        if(food.getSelected().isSelected()) {
                            set.add(new FoodItem(food));
                            food.getSelected().setSelected(false);
                            
                    
                        }
                    }
                    MealItemList.setAll(new HashSet<FoodItem>(set));
                    Collections.sort(MealItemList, new FoodItemComparator<FoodItem>() {
        				@Override
        				public int compare(FoodItem f1, FoodItem f2) {
        					return f1.getName().compareTo(f2.getName());
        				}
        			});
                });
                
                // Sets up alignment for "add Food to Meal" functionality
                VBox addMeal = new VBox();
                addMeal.setSpacing(5);
                addMeal.getChildren().addAll(addMealabel, addMealButton);
                addMealButton.setMinWidth(50);
                addMeal.setAlignment(Pos.CENTER);
                GridPane.setConstraints(addMeal, 1, 0);                 
                GridPane.setConstraints(FoodTableGrid, 0, 0);
                GridPane.setConstraints(MenutableGrid, 2, 0);
                
                
                // Creates Menubar for save and load files
                Menu menu = new Menu("Menu");
                menu.setStyle("-fx-font-size: 20 pt;\r\n" + 
                        "    -fx-font-family: \"Verdana\";\r\n" + 
                        "    -fx-text-fill: #A9A9A9;");
                MenuItem LoadFile = new MenuItem("Load food items from a file");
                MenuItem SaveFile = new MenuItem("Save food list to a file");
                MenuItem Help = new MenuItem("Help");
                MenuItem Exit = new MenuItem("Exit");
                menu.getItems().add(LoadFile);
                menu.getItems().add(SaveFile);
                menu.getItems().add(Help);
                menu.getItems().add(Exit);
                // Sets up action of Exit option
                Exit.setOnAction(e->{
                    primaryStage.close();
                });
                // Sets up action for Help option
                Help.setOnAction(e -> {
                    HelpGUI.Display();
                });

                //Sets up action for FileLoad option
			// Creates file chooser
			FileChooser loadFileChooser = new FileChooser();
			LoadFile.setOnAction(e -> {
				File fileChosen = loadFileChooser.showOpenDialog(primaryStage);
				// fd = new FoodData();
				fd.loadFoodItems(fileChosen.toPath().toString());
				FoodItemList.setAll(fd.getAllFoodItems());
				// Sort
				Collections.sort(FoodItemList, new FoodItemComparator<FoodItem>() {
					@Override
					public int compare(FoodItem f1, FoodItem f2) {
						return f1.getName().compareTo(f2.getName());
					}
				});

                    // counter set
                	Integer count = FoodItemList.size();
        			CountView.setText(count.toString());
                });
                
                //Sets us action for FileSave option
                // Creates file chooser 
                FileChooser saveFileChooser = new FileChooser();
                SaveFile.setOnAction(e -> {
                    File fileChosen = saveFileChooser.showSaveDialog(primaryStage);
                    fd.saveFoodItems(fileChosen.toString());
                });
                
                // place all the Menu options into one MenuBar
                MenuBar menuBar = new MenuBar();      
                menuBar.getMenus().add(menu);
                tableGrid.getChildren().addAll(FoodTableGrid, MenutableGrid, addMeal);
                VBox center = new VBox();
                center.getChildren().addAll(Top,tableGrid);
                Top.setAlignment(Pos.CENTER);
                filterGP.setAlignment(Pos.CENTER);
                
                
                // Adds a exit button on the primary page
                Button exit = new Button("EXIT");
                HBox exitB = new HBox();
                exitB.setSpacing(10);
                exitB.minHeight(200);
                exit.setOnAction(e -> primaryStage.close());
                exitB.getChildren().add(exit);
                exitB.setAlignment(Pos.TOP_RIGHT);
                
                
                // Final Alignment for bigger containers
                root.setBottom(exitB);
                root.setCenter(center);
                root.setTop(menuBar);        
                root.setStyle("-fx-background-image: url(application/background.jpg);");
                Scene scene = new Scene(root,1200,600);
                scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
                return scene;

            } catch(Exception e) {
                e.printStackTrace();
            }
            return null;
            
        }

}