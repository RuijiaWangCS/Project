#include <stdio.h> // for stderr
#include <stdlib.h> // for exit()
#include "types.h"
#include "utils.h"
#include "riscv.h"

void execute_rtype(Instruction, Processor *);
void execute_itype_except_load(Instruction, Processor *);
void execute_branch(Instruction, Processor *);
void execute_jal(Instruction, Processor *);
void execute_load(Instruction, Processor *, Byte *);
void execute_store(Instruction, Processor *, Byte *);
void execute_ecall(Processor *, Byte *);
void execute_lui(Instruction, Processor *);

int bitSigner1( unsigned int field, unsigned int size);

void func_add(Instruction instruction, Processor *processor);
void func_mul(Instruction instruction, Processor *processor);
void func_sub(Instruction instruction, Processor *processor);
void func_sll(Instruction instruction, Processor *processor);
void func_mulh(Instruction instruction, Processor *processor);
void func_slt(Instruction instruction, Processor *processor);
void func_xor(Instruction instruction, Processor *processor);
void func_div(Instruction instruction, Processor *processor);
void func_srl(Instruction instruction, Processor *processor);
void func_sra(Instruction instruction, Processor *processor);
void func_or(Instruction instruction, Processor *processor);
void func_rem(Instruction instruction, Processor *processor);
void func_and(Instruction instruction, Processor *processor);
void func_addi(Instruction instruction, Processor *processor);
void func_slli(Instruction instruction, Processor *processor);
void func_slti(Instruction instruction, Processor *processor);
void func_xori(Instruction instruction, Processor *processor);
void func_srli(Instruction instruction, Processor *processor);
void func_srai(Instruction instruction, Processor *processor);
void func_ori(Instruction instruction, Processor *processor);
void func_andi(Instruction instruction, Processor *processor);
void func_beq(Instruction instruction, Processor *processor, int offset);
void func_bne(Instruction instruction, Processor *processor, int offset);


void execute_instruction(Instruction instruction,Processor *processor,Byte *memory) {
    /* YOUR CODE HERE: COMPLETE THE SWITCH STATEMENTS */
  //  decode_instruction(instruction);
    switch(instruction.opcode) { // What do we switch on?
        /* YOUR CODE HERE */
        case 0x33:
                 execute_rtype(instruction, processor);
                 break;
        case 0x03:
                 execute_load(instruction, processor, memory);
                 break;
        case 0x13:
                 execute_itype_except_load(instruction, processor);
                 break;
        case 0x73:
                 execute_ecall(processor, memory);
                 break;
        case 0x23:
                 execute_store(instruction, processor, memory);
                 break;
        case 0x63:
                 execute_branch(instruction, processor);
                 break;
        case 0x37:
                 execute_lui(instruction, processor);
                 break;
        case 0x6f:
                 execute_jal(instruction, processor);
                 break;
        default: // undefined opcode
            handle_invalid_instruction(instruction);
            exit(-1);
            break;
    }
}

void execute_rtype(Instruction instruction, Processor *processor) {
    switch(instruction.rtype.funct3) { // What do we switch on?
        /* YOUR CODE HERE */
        case 0x0:
                switch(instruction.rtype.funct7) {
                	case 0x00:
                	         func_add(instruction, processor);
                	         break;
                	case 0x01:
                	         func_mul(instruction, processor);
                	         break;
                	case 0x20:
                	         func_sub(instruction, processor);
                	         break;
                	default:
                           handle_invalid_instruction(instruction);
                           exit(-1);
                           break;
                }
                break;
        case 0x1:
                switch(instruction.rtype.funct7) {
                	case 0x00:
                	         func_sll(instruction, processor);
                	         break;
                	case 0x01:
                	         func_mulh(instruction, processor);
                	         break;
                	default:
                           handle_invalid_instruction(instruction);
                           exit(-1);
                           break;
                }
                break;
        case 0x2:
                func_slt(instruction, processor);
                break;
        case 0x4:
                switch(instruction.rtype.funct7) {
                	case 0x00:
                	         func_xor(instruction, processor);
                	         break;
                	case 0x01:
                	         func_div(instruction, processor);
                	         break;
                	default:
                           handle_invalid_instruction(instruction);
                           exit(-1);
                           break;
                }
                break;
        case 0x5:
                switch(instruction.rtype.funct7) {
                	case 0x00:
                	         func_srl(instruction, processor);
                	         break;
                	case 0x20:
                	         func_sra(instruction, processor);
                	         break;
                	default:
                           handle_invalid_instruction(instruction);
                           exit(-1);
                           break;
                }
                break;
        case 0x6:
                switch(instruction.rtype.funct7) {
                	case 0x00:
                	         func_or(instruction, processor);
                	         break;
                	case 0x01:
                	         func_rem(instruction, processor);
                	         break;
                	default:
                           handle_invalid_instruction(instruction);
                           exit(-1);
                           break;
                }
                break;
        case 0x7:
                func_and(instruction, processor);
                break;

        default:
            handle_invalid_instruction(instruction);
            exit(-1);
            break;
    }
}

void execute_itype_except_load(Instruction instruction, Processor *processor) {
    int shiftOp;
    shiftOp = -1;
    switch(instruction.itype.funct3) { // What do we switch on?
        /* YOUR CODE HERE */
        case 0x0:
                func_addi(instruction, processor);
                break;
        case 0x1:
                func_slli(instruction, processor);
                break;
        case 0x2:
                func_slti(instruction, processor);
                break;
        case 0x4:
                func_xori(instruction, processor);
                break;
        case 0x5:
                shiftOp = instruction.itype.imm>>5;
                switch(shiftOp){
                	case 0x00:
                	         func_srli(instruction, processor);
                	         break;
                	case 0x20:
                             func_srai(instruction, processor);
                	         break;
                	default:
                           handle_invalid_instruction(instruction);
                           exit(-1);
                           break;
                }
                break;
        case 0x6:
                func_ori(instruction, processor);
                break;
        case 0x7:
                func_andi(instruction, processor);
                break;
        default:
            handle_invalid_instruction(instruction);
            exit(-1);
            break;
    }
}

void execute_ecall(Processor *p, Byte *memory) {
    switch(p->R[10]) { // What do we switch on?
        /* YOUR CODE HERE */
        case 1:
              printf("%d",p->R[11]);
              p->PC += 4;
              break;
        case 10:
               printf("exiting the simulator\n");
               exit(0);
               break;
        default: // undefined ecall
            printf("Illegal ecall number %d\n", -1); // What stores the ecall arg?
            exit(-1);
            break;
    }
}

void execute_branch(Instruction instruction, Processor *processor) {
    int branchaddr;
    branchaddr = 0;
    branchaddr = get_branch_offset(instruction);
    /* Remember that the immediate portion of branches
       is counting half-words, so make sure to account for that. */
    switch(instruction.sbtype.funct3) { // What do we switch on?
        /* YOUR CODE HERE */
        case 0x0:
                func_beq(instruction, processor, branchaddr);
                break;
        case 0x1:
                func_bne(instruction, processor, branchaddr);
                break;
        default:
            handle_invalid_instruction(instruction);
            exit(-1);
            break;
    }
}

int bitSigner1(unsigned int field, unsigned int size){
    if (size == 32)
	return field;
    if (((field >> (size-1))&0x1) == 0)
      {
       return field;
      }
    else{
        return field | ((~0) << size);
    }
}

void execute_load(Instruction instruction, Processor *processor, Byte *memory) {
    unsigned int rs1 = instruction.itype.rs1;
    int imm = bitSigner1(instruction.itype.imm, 12);
    int address = processor->R[rs1] + imm;
    if (address<0)
	handle_invalid_read(processor->R[rs1]+imm);
    unsigned int rd = instruction.itype.rd;
    switch(instruction.itype.funct3) { // What do we switch on?
        /* YOUR CODE HERE */
        case 0x0:
      //          printf("%d\n", *(memory + processor->R[rs1]));
                processor->R[rd] = load(memory ,processor->R[rs1]+imm,1,0);
                processor->PC += 4;
                break;
        case 0x1:
                processor->R[rd] = load(memory ,processor->R[rs1]+imm,2,0);
                processor->PC += 4;
                break;
        case 0x2:
                processor->R[rd] = load(memory ,processor->R[rs1]+imm,4,0);
                processor->PC += 4;
                break;
        default:
            handle_invalid_instruction(instruction);
            exit(-1);
            break;
    }
}

void execute_store(Instruction instruction, Processor *processor, Byte *memory) {

    unsigned int rs1 = instruction.stype.rs1;
    int imm = get_store_offset(instruction);
    int shift = processor->R[rs1] + imm;
    switch(instruction.stype.funct3) { // What do we switch on?
        /* YOUR CODE HERE */
        case 0x0:
          //      printf("no-store-x2 (lb):%x\nstored:%x\n",*(memory + processor->R[rs1]),processor->R[instruction.stype.rs2] );
                store(memory, shift, 1, processor->R[instruction.stype.rs2] & 0x0ff, 0);
                processor->PC += 4;
      //          printf("store-x2 (lb):%x\n",*(memory + processor->R[rs1]));
                break;
        case 0x1:
                store(memory, shift, 2, processor->R[instruction.stype.rs2] & 0x0ffff, 0);
                processor->PC += 4;
      //          printf("store-x2 (lh):%x\n",*(memory + processor->R[rs1]));
                break;
        case 0x2:
                store(memory, shift, 4, processor->R[instruction.stype.rs2], 0);
                processor->PC += 4;
                break;
        default:
            handle_invalid_instruction(instruction);
            exit(-1);
            break;
    }
}

void execute_jal(Instruction instruction, Processor *processor) {
    int nextPC;
    int offset;

    /* YOUR CODE HERE */
    nextPC = processor->PC + 4;
    offset = get_jump_offset(instruction);
    processor->PC += offset;
    processor->R[instruction.ujtype.rd] = nextPC;
}

void execute_lui(Instruction instruction, Processor *processor) {
    int imm;
    imm = 0;
    /* YOUR CODE HERE */
    imm = instruction.utype.imm << 12;
    processor->R[instruction.utype.rd] = imm;
    processor->PC += 4;
}

/* Checks that the address is aligned correctly */
int check(Address address,Alignment alignment) {
    if(address>0 && address < MEMORY_SPACE){
        if(alignment == LENGTH_BYTE){
            return 1;
        }
        else if( alignment == LENGTH_HALF_WORD ){
            return address%2 == 0;
        }
        else if (alignment == LENGTH_WORD){
            return address%4 ==0;
        }
    }

    return 0;

}

void store(Byte *memory,Address address,Alignment alignment,Word value, int check_align) {
    if((check_align && !check(address,alignment)) || (address >= MEMORY_SPACE)) {
        handle_invalid_write(address);
    }
    /* YOUR CODE HERE */
    int n = 0;
    *(memory + address + n) = value & 0x0ff;
    value = value>>8;
    n += 1;
    while(n < alignment){
      *(memory + address + n) = value & 0x0ff;
      value = value>>8;
      n += 1;
    }
}

Word load(Byte *memory,Address address,Alignment alignment, int check_align) {
    if((check_align && !check(address,alignment)) || (address >= MEMORY_SPACE)) {
    handle_invalid_read(address);
    }
    /* YOUR CODE HERE */
    uint32_t data = 0; // initialize our return value to zero
    data = bitSigner((data | *(memory + address + alignment - 1)), 8);
    alignment -= 1;
    while(alignment > 0){
      data = data<<8;
      data = data | *(memory + address + alignment - 1);
      alignment -= 1;
    }
//    printf("load-data:%x\n", data);
    return data;
}

void func_add(Instruction instruction, Processor *processor) {
	processor->R[instruction.rtype.rd] = (int)processor->R[instruction.rtype.rs1] + (int)processor->R[instruction.rtype.rs2];
	processor->PC += 4;
}

void func_mul(Instruction instruction, Processor *processor) {
	processor->R[instruction.rtype.rd] = processor->R[instruction.rtype.rs1] * processor->R[instruction.rtype.rs2];
	processor->PC += 4;
}

void func_sub(Instruction instruction, Processor *processor) {
	processor->R[instruction.rtype.rd] = (int)processor->R[instruction.rtype.rs1] - (int)processor->R[instruction.rtype.rs2];
	processor->PC += 4;
}

void func_sll(Instruction instruction, Processor *processor) {
	processor->R[instruction.rtype.rd] = processor->R[instruction.rtype.rs1]<<(processor->R[instruction.rtype.rs2]);
	processor->PC += 4;
}

void func_mulh(Instruction instruction, Processor *processor) {
	long long int x = (long long int)(processor->R[instruction.rtype.rs1]) * ((long long int)(processor->R[instruction.rtype.rs2]));
  processor->R[instruction.rtype.rd] = (long int)(x>>32);
  processor->PC += 4;
}

void func_slt(Instruction instruction, Processor *processor) {
  //  printf("rs1:%d\nrs2:%d\n",processor->R[instruction.rtype.rs1],processor->R[instruction.rtype.rs2]);
    if((int)(processor->R[instruction.rtype.rs1]) < (int)(processor->R[instruction.rtype.rs2]))
      {//printf("1\n");
    	processor->R[instruction.rtype.rd] = 1;}
    else
      {//printf("0\n");
    	processor->R[instruction.rtype.rd] = 0;}
    processor->PC += 4;
}

void func_xor(Instruction instruction, Processor *processor) {
	processor->R[instruction.rtype.rd] = processor->R[instruction.rtype.rs1] ^ processor->R[instruction.rtype.rs2];
	processor->PC += 4;
}

void func_div(Instruction instruction, Processor *processor) {
	processor->R[instruction.rtype.rd] = processor->R[instruction.rtype.rs1] / processor->R[instruction.rtype.rs2];
	processor->PC += 4;
}

void func_srl(Instruction instruction, Processor *processor) {
	processor->R[instruction.rtype.rd] = processor->R[instruction.rtype.rs1]>>(int)processor->R[instruction.rtype.rs2];
	processor->PC += 4;
}

void func_sra(Instruction instruction, Processor *processor) {
    	processor->R[instruction.rtype.rd] = bitSigner(processor->R[instruction.rtype.rs1]>>(processor->R[instruction.rtype.rs2] & 31), 32-(processor->R[instruction.rtype.rs2] & 31));
      processor->PC += 4;
}

void func_or(Instruction instruction, Processor *processor) {
	processor->R[instruction.rtype.rd] = processor->R[instruction.rtype.rs1] | processor->R[instruction.rtype.rs2];
	processor->PC += 4;
}

void func_rem(Instruction instruction, Processor *processor) {
	processor->R[instruction.rtype.rd] = processor->R[instruction.rtype.rs1] % processor->R[instruction.rtype.rs2];
	processor->PC += 4;
}

void func_and(Instruction instruction, Processor *processor) {
	processor->R[instruction.rtype.rd] = processor->R[instruction.rtype.rs1] & processor->R[instruction.rtype.rs2];
	processor->PC += 4;
}

void func_addi(Instruction instruction, Processor *processor) {
	processor->R[instruction.itype.rd] = (int) processor->R[instruction.itype.rs1] + bitSigner1(instruction.itype.imm, 12);
	processor->PC += 4;
}

void func_slli(Instruction instruction, Processor *processor) {
	processor->R[instruction.itype.rd] = processor->R[instruction.itype.rs1]<<bitSigner(instruction.itype.imm, 12);
	processor->PC += 4;
}

void func_slti(Instruction instruction, Processor *processor) {
    int rs1, imm;
    rs1 = processor->R[instruction.itype.rs1];
    imm = bitSigner(instruction.itype.imm, 12);
    processor->R[instruction.itype.rd] = (rs1 < imm) ? 1 : 0;
    processor->PC += 4;
}

void func_xori(Instruction instruction, Processor *processor) {
	processor->R[instruction.itype.rd] = processor->R[instruction.itype.rs1] ^ bitSigner(instruction.itype.imm, 12);
	processor->PC += 4;
}

void func_srli(Instruction instruction, Processor *processor) {
	processor->R[instruction.itype.rd] = processor->R[instruction.itype.rs1]>>bitSigner(instruction.itype.imm, 12);
	processor->PC += 4;
}

void func_srai(Instruction instruction, Processor *processor) {
  //  printf("srai:%x\n",processor->R[instruction.itype.rs1]);
    int shiftop = instruction.itype.imm & 31;
		processor->R[instruction.itype.rd] = bitSigner(processor->R[instruction.itype.rs1]>>shiftop, (32 - shiftop));
    processor->PC += 4;
}

void func_ori(Instruction instruction, Processor *processor) {
	processor->R[instruction.itype.rd] = processor->R[instruction.itype.rs1] | bitSigner(instruction.itype.imm, 12);
	processor->PC += 4;
}

void func_andi(Instruction instruction, Processor *processor) {
	processor->R[instruction.itype.rd] = processor->R[instruction.itype.rs1] & bitSigner(instruction.itype.imm, 12);
	processor->PC += 4;
}

void func_beq(Instruction instruction, Processor *processor, int offset) {
  if(processor->R[instruction.sbtype.rs1] == processor->R[instruction.sbtype.rs2])
    processor->PC += offset;
	else
    processor->PC += 4;
}

void func_bne(Instruction instruction, Processor *processor, int offset) {
  if(processor->R[instruction.sbtype.rs1] != processor->R[instruction.sbtype.rs2])
    processor->PC += offset;
	else
    processor->PC += 4;
}
