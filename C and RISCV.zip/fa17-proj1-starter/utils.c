#include "utils.h"
#include <stdio.h>
#include <stdlib.h>

//sign extends a bitfield with given size
/* You may find implementing this function helpful */
int bitSigner( unsigned int field, unsigned int size){
    /* YOUR CODE HERE */
    if((field & (0x00000001 << (size-1))) == 0)
      {  
       return field | 0x00000000;
    }
    else{
        return field | (0xffffffff << size);
    }
}

/* Remember that the offsets should return the offset in BYTES */

int get_branch_offset(Instruction instruction) {
    /* YOUR CODE HERE */
    return ((instruction.sbtype.imm5>>1)*2) | ((instruction.sbtype.imm7&0b0111111)<<5) | ((instruction.sbtype.imm5&0b1)<<11) | bitSigner(((instruction.sbtype.imm7>>6)<<12),13) ;
}


int get_jump_offset(Instruction instruction) {
    /* YOUR CODE HERE */
    return (((instruction.ujtype.imm>>9) & 0b01111111111)*2 )| (((instruction.ujtype.imm>>8)&1)<<11) | ((instruction.ujtype.imm&0b11111111)<<12) | (bitSigner((instruction.ujtype.imm>>19)<<20, 21));
}

int get_store_offset(Instruction instruction) {
    /* YOUR CODE HERE */
    return (instruction.stype.imm5 + bitSigner(instruction.stype.imm7<<5, 12));
}

void handle_invalid_instruction(Instruction instruction) {
    printf("\n%d\n",instruction.opcode);
    printf("Invalid Instruction: 0x%08x\n", instruction.bits); 
}

void handle_invalid_read(Address address) {
    printf("Bad Read. Address: 0x%08x\n", address);
    exit(-1);
}

void handle_invalid_write(Address address) {
    printf("Bad Write. Address: 0x%08x\n", address);
    exit(-1);
}

