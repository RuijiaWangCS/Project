#include "matrix.h"

#include <omp.h>
// Include SSE intrinsics
#if defined(_MSC_VER)
#include <intrin.h>
#elif defined(__GNUC__) && (defined(__x86_64__) || defined(__i386__))
#include <immintrin.h>
#include <x86intrin.h>
#endif

/*
    called like:
    ```c
    matrix mat;
    allocate_matrix(&mat, 1, 2);
    ```
*/

  //  __m128 _mm_mul_ps (__m128 a, __m128 b)
  // __m128 _mm_loadu_ps (float const* mem_addr)
  //  __m128 _mm_add_ps (__m128 a, __m128 b)
  //  _mm_storeu_ps (float* mem_addr, __m128 a)


int allocate_matrix(matrix **mat, int rows, int cols) {
    *mat = malloc(sizeof(matrix));
    (*mat)->dim.rows = rows;
    (*mat)->dim.cols = cols;
    (*mat)->data = malloc(sizeof(float *) * rows);
    for (int i = 0; i < rows/4*4 ; i+=4) {
        (*mat)->data[i] = calloc(cols, sizeof(float));
        (*mat)->data[i+1] = calloc(cols, sizeof(float));
        (*mat)->data[i+2] = calloc(cols, sizeof(float));
        (*mat)->data[i+3] = calloc(cols, sizeof(float));

    }
    for(int i = rows/4*4; i < rows; i++){
        (*mat)->data[i] = calloc(cols, sizeof(float));
    }
    return 0;
}

int allocate_matrix_s(matrix **mat, shape s) {
    return allocate_matrix(mat, s.rows, s.cols);
}

int eye(matrix **mat, shape s) {
    assert(allocate_matrix_s(mat, s) == 0);
    // Make the result an identity matrix
    for (int i = 0; i < s.rows/4*4; i+=4) {
        (*mat)->data[i][i] = 1;
        (*mat)->data[i+1][i+1] = 1;
        (*mat)->data[i+2][i+2] = 1;
        (*mat)->data[i+3][i+3] = 1;
    }
    for(int i = s.rows/4*4; i < s.rows; i++){
        (*mat)->data[i][i] = 1;
    }
    return 0;
}

void free_matrix(matrix *mat) {
    for (int i = 0; i < (mat->dim.rows)/4*4; i+=4) {
        free(mat->data[i]);
        free(mat->data[i+1]);
        free(mat->data[i+2]);
        free(mat->data[i+3]);
    }
    for(int i = (mat->dim.rows)/4*4; i < mat->dim.rows; i++){
        free(mat->data[i]);
    }
    free(mat->data);
    free(mat);
}

void dot_product(matrix *vec1, matrix *vec2, float *result) {
    assert(same_size(vec1, vec2) && vec1->dim.cols == 1);
    *result = 0;
  //  既可以用simd指令， 也可以用openmp
  //  for (int i = 0; i < vec1->dim.rows; i++) {
  //      *result += vec1->data[i][0] * vec2->data[i][0];
  //  }
    #pragma omp parallel
    {

        float val[4];
        __m128 vec1_item1 = _mm_setzero_ps();
        __m128 vec1_item2 = _mm_setzero_ps();
        __m128 vec1_item3 = _mm_setzero_ps();
        __m128 vec1_item4 = _mm_setzero_ps();
        __m128 vec2_item1 = _mm_setzero_ps();
        __m128 vec2_item2 = _mm_setzero_ps();
        __m128 vec2_item3 = _mm_setzero_ps();
        __m128 vec2_item4 = _mm_setzero_ps();
        __m128 sum = _mm_setzero_ps();
        float total = 0;

        #pragma omp for
            for (int i = 0; i < (vec1->dim.rows)/16*16; i+=16) {
                vec1_item1 = _mm_loadu_ps(*(vec1->data + i));
                vec2_item1 = _mm_loadu_ps(*(vec2->data + i));
                sum = _mm_add_ps (sum, _mm_mul_ps(vec1_item1, vec2_item1));

                vec1_item2 = _mm_loadu_ps(*(vec1->data + i) + 4);
                vec2_item2 = _mm_loadu_ps(*(vec2->data + i) + 4);
                sum = _mm_add_ps (sum, _mm_mul_ps(vec1_item2, vec2_item2));

                vec1_item3 = _mm_loadu_ps(*(vec1->data + i) + 8);
                vec2_item3 = _mm_loadu_ps(*(vec2->data + i) + 8);
                sum = _mm_add_ps (sum, _mm_mul_ps(vec1_item3, vec2_item3));

                vec1_item4 = _mm_loadu_ps(*(vec1->data + i) + 12);
                vec2_item4 = _mm_loadu_ps(*(vec2->data + i) + 12);
                sum = _mm_add_ps (sum, _mm_mul_ps(vec1_item4, vec2_item4));

            }

            for(int i = (vec1->dim.rows)/16*16; i<vec1->dim.rows; i++){
                 total += vec1->data[i][0] * vec2->data[i][0];
            }
            
            _mm_storeu_ps(val, sum);

            for(int i = 0; i < 4; i++){
                total += val[i];
            }

        #pragma omp critial
            *result += total;
    }
}

void outer_product(matrix *vec1, matrix *vec2, matrix *dst) {
    assert(vec1->dim.cols == 1 && vec2->dim.cols == 1 && vec1->dim.rows == dst->dim.rows && vec2->dim.rows == dst->dim.cols);
//    for (int i = 0; i < vec1->dim.rows; i++) {
//        for (int j = 0; j < vec2->dim.rows; j++) {
//            dst->data[i][j] = vec1->data[i][0] * vec2->data[j][0];
//        }
//    }
    #pragma omp parallel
    {
        __m128 vec1_item1 = _mm_setzero_ps();
        __m128 vec1_item2 = _mm_setzero_ps();
        __m128 vec1_item3 = _mm_setzero_ps();
        __m128 vec1_item4 = _mm_setzero_ps();
        __m128 vec2_item1 = _mm_setzero_ps();
        __m128 vec2_item2 = _mm_setzero_ps();
        __m128 vec2_item3 = _mm_setzero_ps();
        __m128 vec2_item4 = _mm_setzero_ps();

        #pragma omp for
        for (int i = 0; i < vec1->dim.rows; i++) {
            for (int j = 0; j < (vec2->dim.rows)/16*16; j+=16) {
                vec1_item1 = _mm_loadu_ps(*(vec1->data + i));
                vec2_item1 = _mm_loadu_ps(*(vec2->data + i));
                _mm_storeu_ps(*(dst->data+i)+j, _mm_mul_ps(vec1_item1, vec2_item1));

                vec1_item2 = _mm_loadu_ps(*(vec1->data + i) + 4);
                vec2_item2 = _mm_loadu_ps(*(vec2->data + i) + 4);
                _mm_storeu_ps(*(dst->data+i)+(j+4), _mm_mul_ps(vec1_item2, vec2_item2));

                vec1_item3 = _mm_loadu_ps(*(vec1->data + i) + 8);
                vec2_item3 = _mm_loadu_ps(*(vec2->data + i) + 8);
                _mm_storeu_ps(*(dst->data+i)+(j+8), _mm_mul_ps(vec1_item3, vec2_item3));

                vec1_item4 = _mm_loadu_ps(*(vec1->data + i) + 12);
                vec2_item4 = _mm_loadu_ps(*(vec2->data + i) + 12);
                _mm_storeu_ps(*(dst->data+i)+(j+12), _mm_mul_ps(vec1_item4, vec2_item4));
            }

            for (int j = (vec2->dim.rows)/16*16; j < vec2->dim.rows; j++) {
                dst->data[i][j] = vec1->data[i][0] * vec2->data[j][0];
            }
        }
    }
}

void matrix_power(matrix *mat, int pow, matrix *dst) {
    assert(mat != dst && same_size(mat, dst) && mat->dim.rows == mat->dim.cols);
    if (pow == 1) {
        copy(mat, dst);
        return;
    }
    if (pow == 2) {
        matrix_multiply(mat, mat, dst);
        return;
    }

    matrix* intermediate;
    eye(&intermediate, dst->dim);
    copy(intermediate, dst);
    for (int i = 0; i < pow; i++) {
        matrix_multiply(intermediate, mat, dst);
        copy(dst, intermediate);
    }
    free_matrix(intermediate);
}

void matrix_multiply(matrix *mat1, matrix *mat2, matrix *dst) {
    assert (mat1->dim.cols == mat2->dim.rows && dst->dim.rows == mat1->dim.rows && dst->dim.cols == mat2->dim.cols);
//    for (int i = 0; i < mat1->dim.rows; i++)
//        for (int j = 0; j < mat2->dim.cols; j++) {
//            dst->data[i][j] = 0; //Ensures that the destination matrix is zeros initially. 
//            for (int k = 0; k < mat1->dim.cols; k++)
//                dst->data[i][j] += mat1->data[i][k] * mat2->data[k][j];
//        }

//    __m128 _mm_set_ps (float e3, float e2, float e1, float e0)

    #pragma omp parallel
    {
        __m128 mat1_item1 = _mm_setzero_ps();
        __m128 mat1_item2 = _mm_setzero_ps();
        __m128 mat1_item3 = _mm_setzero_ps();
        __m128 mat1_item4 = _mm_setzero_ps();
        __m128 mat2_item1 = _mm_setzero_ps();
        __m128 mat2_item2 = _mm_setzero_ps();
        __m128 mat2_item3 = _mm_setzero_ps();
        __m128 mat2_item4 = _mm_setzero_ps();
        #pragma omp for
        for (int i = 0; i < mat1->dim.rows; i++)
            for (int j = 0; j < mat2->dim.cols; j++) {
                dst->data[i][j] = 0; //Ensures that the destination matrix is zeros initially. 
                for (int k = 0; k < mat1->dim.cols/16*16; k+=16){
                    mat1_item1 = _mm_loadu_ps(*(mat1->data + i) + k);
                    mat2_item1 = _mm_set_ps(mat2->data[k+3][j], mat2->data[k+2][j], mat2->data[k+1][j], mat2->data[k][j]);
                    _mm_storeu_ps(*(dst->data+i)+j, _mm_mul_ps(mat1_item1, mat2_item1));

                    mat1_item2 = _mm_loadu_ps(*(mat1->data + i) + k + 4);
                    mat2_item2 = _mm_set_ps(mat2->data[k+7][j], mat2->data[k+6][j], mat2->data[k+5][j], mat2->data[k+4][j]);
                    _mm_storeu_ps(*(dst->data+i)+(j+4), _mm_mul_ps(mat1_item2, mat2_item2));

                    mat1_item3 = _mm_loadu_ps(*(mat1->data + i) + k + 8);
                    mat2_item3 = _mm_set_ps(mat2->data[k+11][j], mat2->data[k+10][j], mat2->data[k+9][j], mat2->data[k+8][j]);
                    _mm_storeu_ps(*(dst->data+i)+(j+8), _mm_mul_ps(mat1_item3, mat2_item3));

                    mat1_item4 = _mm_loadu_ps(*(mat1->data + i) + k + 12);
                    mat2_item4 = _mm_set_ps(mat2->data[k+15][j], mat2->data[k+14][j], mat2->data[k+13][j], mat2->data[k+12][j]);
                    _mm_storeu_ps(*(dst->data+i)+(j+12), _mm_mul_ps(mat1_item4, mat2_item4));
                }

                for (int k = mat1->dim.cols/16*16; k < mat1->dim.cols; k++)
                    dst->data[i][j] += mat1->data[i][k] * mat2->data[k][j];
            }
    }
}

void matrix_scale(matrix *mat, float scalar, matrix *dst) {
    assert(same_size(mat, dst));

//    for (int i = 0; i < mat->dim.rows; i++) {
//        for (int j = 0; j < mat->dim.cols; j++) {
//            dst->data[i][j] = scalar * mat->data[i][j];
//        }
//    }

//    __m128 _mm_set1_ps (float a)

    #pragma omp parallel
    {
        __m128 mat_item1 = _mm_setzero_ps();
        __m128 mat_item2 = _mm_setzero_ps();
        __m128 mat_item3 = _mm_setzero_ps();
        __m128 mat_item4 = _mm_setzero_ps();
        __m128 vec_scalar = _mm_set1_ps(scalar);

        #pragma omp for
        for (int i = 0; i < mat->dim.rows; i++) {
            for (int j = 0; j < mat->dim.cols/16*16; j+=16) {
                mat_item1 = _mm_loadu_ps(*(mat->data + i) + j);
                _mm_storeu_ps(*(dst->data + i) + j, _mm_mul_ps(vec_scalar, mat_item1));

                mat_item2 = _mm_loadu_ps(*(mat->data + i) + j + 4);
                _mm_storeu_ps(*(dst->data + i) + j + 4, _mm_mul_ps(vec_scalar, mat_item2));

                mat_item3 = _mm_loadu_ps(*(mat->data + i) + j + 8);
                _mm_storeu_ps(*(dst->data + i) + j + 8, _mm_mul_ps(vec_scalar, mat_item3));

                mat_item4 = _mm_loadu_ps(*(mat->data + i) + j + 12);
                _mm_storeu_ps(*(dst->data + i) + j + 12, _mm_mul_ps(vec_scalar, mat_item4));
            }

            for (int j = mat->dim.cols/16*16; j < mat->dim.cols; j++) {
                dst->data[i][j] = scalar * mat->data[i][j];
            }
        }  
    }
}

void apply_func(matrix* mat, matrix* dst, float (*f)(float)) {
    assert(same_size(mat, dst));
//    for (int i = 0; i < mat->dim.rows; i++) {
//        for (int j = 0; j < mat->dim.cols; j++) {
//            dst->data[i][j] = f(mat->data[i][j]);
//        }
//    }
    #pragma omp parallel
    {
        __m128 mat_item1 = _mm_setzero_ps();
        __m128 mat_item2 = _mm_setzero_ps();
        __m128 mat_item3 = _mm_setzero_ps();
        __m128 mat_item4 = _mm_setzero_ps();

        #pragma omp for
        for (int i = 0; i < mat->dim.rows; i++) {
            for (int j = 0; j < mat->dim.cols/16*16; j+=16) {
                mat_item1 = _mm_set_ps(f(mat->data[i][j+3]), f(mat->data[i][j+2]), f(mat->data[i][j+1]), f(mat->data[i][j]));
                _mm_storeu_ps(*(dst->data + i) + j, mat_item1);

                mat_item2 = _mm_set_ps(f(mat->data[i][j+7]), f(mat->data[i][j+6]), f(mat->data[i][j+5]), f(mat->data[i][j+4]));
                _mm_storeu_ps(*(dst->data + i) + j + 4, mat_item2);

                mat_item3 = _mm_set_ps(f(mat->data[i][j+11]), f(mat->data[i][j+10]), f(mat->data[i][j+9]), f(mat->data[i][j+8]));
                _mm_storeu_ps(*(dst->data + i) + j + 8, mat_item3);

                mat_item4 = _mm_set_ps(f(mat->data[i][j+15]), f(mat->data[i][j+14]), f(mat->data[i][j+13]), f(mat->data[i][j+12]));
                _mm_storeu_ps(*(dst->data + i) + j + 12, mat_item4);
            }

            for (int j = mat->dim.cols/16*16; j < mat->dim.cols; j++) {
                dst->data[i][j] = f(mat->data[i][j]);
            }
        }
    }
}

void matrix_multiply_elementwise(matrix *mat1, matrix *mat2, matrix *dst) {
    assert(same_size(mat1, mat2) && same_size(mat1, dst));
//    for (int i = 0; i < dst->dim.rows; i++) {
//        for (int j = 0; j < dst->dim.cols; j++) {
//            dst->data[i][j] = mat1->data[i][j] * mat2->data[i][j];
//        }
//    }
    #pragma omp parallel
    {
        __m128 mat1_item1 = _mm_setzero_ps();
        __m128 mat1_item2 = _mm_setzero_ps();
        __m128 mat1_item3 = _mm_setzero_ps();
        __m128 mat1_item4 = _mm_setzero_ps();
        __m128 mat2_item1 = _mm_setzero_ps();
        __m128 mat2_item2 = _mm_setzero_ps();
        __m128 mat2_item3 = _mm_setzero_ps();
        __m128 mat2_item4 = _mm_setzero_ps();
        #pragma omp for
        for (int i = 0; i < dst->dim.rows; i++) {
            for (int j = 0; j < dst->dim.cols/16*16; j+=16) {
                mat1_item1 = _mm_loadu_ps(*(mat1->data + i) + j);
                mat2_item1 = _mm_loadu_ps(*(mat2->data + i) + j);
                _mm_storeu_ps(*(dst->data + i) + j, _mm_mul_ps(mat1_item1, mat2_item1));

                mat1_item2 = _mm_loadu_ps(*(mat1->data + i) + j + 4);
                mat2_item2 = _mm_loadu_ps(*(mat2->data + i) + j + 4);
                _mm_storeu_ps(*(dst->data + i) + j + 4, _mm_mul_ps(mat1_item2, mat2_item2));

                mat1_item3 = _mm_loadu_ps(*(mat1->data + i) + j + 8);
                mat2_item3 = _mm_loadu_ps(*(mat2->data + i) + j + 8);
                _mm_storeu_ps(*(dst->data + i) + j + 8, _mm_mul_ps(mat1_item3, mat2_item3));

                mat1_item4 = _mm_loadu_ps(*(mat1->data + i) + j + 12);
                mat2_item4 = _mm_loadu_ps(*(mat2->data + i) + j + 12);
                _mm_storeu_ps(*(dst->data + i) + j + 12, _mm_mul_ps(mat1_item4, mat2_item4));
            }
            for (int j = dst->dim.cols/16*16; j < dst->dim.cols; j++) {
                dst->data[i][j] = mat1->data[i][j] * mat2->data[i][j];
            }
        }
    }
}

void matrix_add(matrix *mat1, matrix *mat2, matrix *dst) {
    assert(same_size(mat1, mat2) && same_size(mat1, dst));
//    for (int i = 0; i < dst->dim.rows; i++) {
//        for (int j = 0; j < dst->dim.cols; j++) {
//            dst->data[i][j] = mat1->data[i][j] + mat2->data[i][j];
//        }
//    }
    #pragma omp parallel
    {
        __m128 mat1_item1 = _mm_setzero_ps();
        __m128 mat1_item2 = _mm_setzero_ps();
        __m128 mat1_item3 = _mm_setzero_ps();
        __m128 mat1_item4 = _mm_setzero_ps();
        __m128 mat2_item1 = _mm_setzero_ps();
        __m128 mat2_item2 = _mm_setzero_ps();
        __m128 mat2_item3 = _mm_setzero_ps();
        __m128 mat2_item4 = _mm_setzero_ps();
        #pragma omp for
        for (int i = 0; i < dst->dim.rows; i++) {
            for (int j = 0; j < dst->dim.cols/16*16; j+=16) {
                mat1_item1 = _mm_loadu_ps(*(mat1->data + i) + j);
                mat2_item1 = _mm_loadu_ps(*(mat2->data + i) + j);
                _mm_storeu_ps(*(dst->data + i) + j, _mm_add_ps(mat1_item1, mat2_item1));

                mat1_item2 = _mm_loadu_ps(*(mat1->data + i) + j + 4);
                mat2_item2 = _mm_loadu_ps(*(mat2->data + i) + j + 4);
                _mm_storeu_ps(*(dst->data + i) + j + 4, _mm_add_ps(mat1_item2, mat2_item2));

                mat1_item3 = _mm_loadu_ps(*(mat1->data + i) + j + 8);
                mat2_item3 = _mm_loadu_ps(*(mat2->data + i) + j + 8);
                _mm_storeu_ps(*(dst->data + i) + j + 8, _mm_add_ps(mat1_item3, mat2_item3));

                mat1_item4 = _mm_loadu_ps(*(mat1->data + i) + j + 12);
                mat2_item4 = _mm_loadu_ps(*(mat2->data + i) + j + 12);
                _mm_storeu_ps(*(dst->data + i) + j + 12, _mm_add_ps(mat1_item4, mat2_item4));
            }
            for (int j = dst->dim.cols/16*16; j < dst->dim.cols; j++) {
                dst->data[i][j] = mat1->data[i][j] + mat2->data[i][j];
            }
        }
    }
}

void matrix_transpose(matrix *m, matrix *dst) {
    assert(m->dim.rows == dst->dim.cols && m->dim.cols == dst->dim.rows);
//    for (int i = 0; i < dst->dim.rows; i++) {
//        for (int j = 0; j < dst->dim.cols; j++) {
//            dst->data[i][j] = m->data[j][i];
//        }
//    }

    #pragma omp parallel
    {
        __m128 m_item1 = _mm_setzero_ps();
        __m128 m_item2 = _mm_setzero_ps();
        __m128 m_item3 = _mm_setzero_ps();
        __m128 m_item4 = _mm_setzero_ps();
        for (int i = 0; i < dst->dim.rows; i++) {
            for (int j = 0; j < dst->dim.cols/16*16; j+=16) {
                m_item1 = _mm_set_ps(m->data[j+3][i], m->data[j+2][i], m->data[j+1][i], m->data[j][i]);
                _mm_storeu_ps(*(dst->data + i) + j, m_item1);

                m_item2 = _mm_set_ps(m->data[j+7][i], m->data[j+6][i], m->data[j+5][i], m->data[j+4][i]);
                _mm_storeu_ps(*(dst->data + i) + j + 4, m_item2);

                m_item3 = _mm_set_ps(m->data[j+11][i], m->data[j+10][i], m->data[j+9][i], m->data[j+8][i]);
                _mm_storeu_ps(*(dst->data + i) + j + 8, m_item3);

                m_item4 = _mm_set_ps(m->data[j+15][i], m->data[j+14][i], m->data[j+13][i], m->data[j+12][i]);
                _mm_storeu_ps(*(dst->data + i) + j + 12, m_item4);
            }
            for (int j = dst->dim.cols/16*16; j < dst->dim.cols; j++) {
                dst->data[i][j] = m->data[j][i];
            }
        }
    }
}

void copy(matrix *src, matrix *dst) {
    assert(same_size(src, dst));
//    for (int i = 0; i < src->dim.rows; i++) {
//        for (int j = 0; j < src->dim.cols; j++) {
//            dst->data[i][j] = src->data[i][j];
//        }
//    }
    #pragma omp parallel
    {
        __m128 src_item1 = _mm_setzero_ps();
        __m128 src_item2 = _mm_setzero_ps();
        __m128 src_item3 = _mm_setzero_ps();
        __m128 src_item4 = _mm_setzero_ps();
        #pragma omp for
        for (int i = 0; i < src->dim.rows; i++) {
            for (int j = 0; j < (src->dim.cols)/16*16; j+=16) {
                src_item1 = _mm_loadu_ps(*(src->data + i) + j);
                _mm_storeu_ps(*(dst->data + i) + j, src_item1);

                src_item2 = _mm_loadu_ps(*(src->data + i) + (j + 4));
                _mm_storeu_ps(*(dst->data + i) + (j + 4), src_item2);

                src_item3 = _mm_loadu_ps(*(src->data + i) + (j + 8));
                _mm_storeu_ps(*(dst->data + i) + (j + 8), src_item3);

                src_item4 = _mm_loadu_ps(*(src->data + i) + (j + 12));
                _mm_storeu_ps(*(dst->data + i) + (j + 12), src_item4);
            }
            for (int j = (src->dim.cols)/16*16; j < src->dim.cols; j++) {
                dst->data[i][j] = src->data[i][j];
            }
        }
    }
}


int get_rows(matrix *mat) {
    return mat->dim.rows;
}

int get_cols(matrix *mat) {
    return mat->dim.cols;
}

void get_matrix_as_array(float *arr, matrix *mat) {
    int i, j, k = 0;
    for (i = 0; i < mat->dim.rows; i++) {
        for (j = 0; j < mat->dim.cols; j++) {
            arr[k] = mat->data[i][j];
            k++;
        }
    }
}

matrix* arr_to_matrix(float *arr, int rows, int cols) {
    matrix *m;
    allocate_matrix(&m, rows, cols);
   
//    for (int i = 0; i < rows; i++) {
//        for (int j = 0; j < cols; j++) {
//            set_loc(m, i, j, arr[i*cols + j]);
//        }
//    }
   
    #pragma omp parallel
    {
        #pragma omp for
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols/4*4; j+=4) {
                set_loc(m, i, j, arr[i*cols + j]);
                set_loc(m, i, j+1, arr[i*cols + j+1]);
                set_loc(m, i, j+2, arr[i*cols + j+2]);
                set_loc(m, i, j+3, arr[i*cols + j+3]);
            }
            for (int j = cols/4*4; j < cols; j++) {
                set_loc(m, i, j, arr[i*cols + j]);
            }
        }
    }
    return m;
}

void set_loc(matrix *mat, int row, int col, float val) {
    assert (row < mat->dim.rows && col < mat->dim.cols && row >= 0 && col >= 0);
    mat->data[row][col] = val;
}

int same_size(matrix *mat1, matrix *mat2) {
    return mat1 && mat2 && mat1->dim.rows == mat2->dim.rows && mat1->dim.cols == mat2->dim.cols;
}

float get_loc(matrix *mat, int row, int col) {
    return mat->data[row][col];
}