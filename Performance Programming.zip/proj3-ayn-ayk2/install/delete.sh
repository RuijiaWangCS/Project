#!/bin/bash/

echo "y" | conda remove -n venv --all
